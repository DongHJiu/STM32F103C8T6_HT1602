/**
* @STM32F103C8T6���ƶ�����(HT1620����)-->DHT11�¶Ȳɼ���ʾ
* @������(HT1620����)��CS --> A1 
*                      WR --> A2 
*                      DATA --> A3
*
* @DHT11��DATA --> B0 
**/


#include "stm32f10x.h"                  // Device header
#include "OLED.h"
#include "Delay.h"
#include "LED.h"
#include "Text.h"
#include "DHT.h"



void DHT11_Temperature(void){
	int Temperature_Data_s;
	int Temperature_Data;
	int Temperature_Decimals;
	DHT11_ReadData();                         //��ȡDHT11�¶�
	if(ret==0){
	  Temperature_Data = p[2] /1 %10;         //ȡ�¶�ֵ�ĸ�λ  
    Temperature_Data_s = p[2] /10 %10; 		  //ȡ�¶�ֵ��ʮλ
		Temperature_Decimals = p[3];            //ȡ�¶�ֵ��С��
	}
	Txet_LED_3(Temperature_Decimals, 1);
	Txet_LED_2(Temperature_Data);
	Txet_LED_1(Temperature_Data_s);
	
	Text_LCD_T(100,0,p[2]);
}

int main(void){
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
 	GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIO_WriteBit(GPIOB,GPIO_Pin_7,Bit_RESET);
	OLED_Init();
	
	HT1620_Init();
	DHT11_Init();
  Text_empty();
	Text_LCD_Z();  
	
	while(1){
		DHT11_Temperature();
		Delay_s(3);
	}
	
}



