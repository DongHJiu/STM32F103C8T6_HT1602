#include "stm32f10x.h"                  // Device header
#include "Delay.h"

u8 p[5];
u8 ret;

void GPIO_DTH11(void){
	//RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO|RCC_APB2Periph_GPIOB,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_Out_OD; 
	GPIO_InitStruct.GPIO_Pin=GPIO_Pin_0;  
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStruct);  
	GPIO_WriteBit(GPIOB,  GPIO_Pin_0, Bit_SET);

}

//�������Ϳ�ʼ�ź�
void Mcu_start(void)
{
  GPIO_WriteBit(GPIOB, GPIO_Pin_0, Bit_RESET);
  Delay_ms(18);                                
  GPIO_WriteBit(GPIOB, GPIO_Pin_0, Bit_SET);    
 
}

//�ȴ�DHT11��Ӧ
//1Ϊʧ�ܣ�0Ϊ�ɹ�
u8 dht11_response(void)
{
	u8 i =0;
	while(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0)==1)
	{
	i++;
		Delay_us(1);
		if(i>50)
		{
		return 1;
		}
	}
	
    while(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0)==0);    
	while(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0)==1);      
	return 0;          
  
}

//����λ�⵽������
u8 DH11_ReadByte(void)
{
	u8 i,data=0;
	for(i=0; i<8; i++)
	{
		while(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0)==0);    
		Delay_us(50);
		data =data<<1;
		if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0)==1)   
		{
		//data |=1;
			Delay_us(15);
			if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0)==1){data |=0x01;}
			else{data &=0xfe;};		
		}
		while(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0)==1);  
	}
	return data;
}


//��40λ����
u8 DHT11_ReadData(void)
{
	Mcu_start();   
	ret = dht11_response();
	if (ret)
	{
	return 1;
	}
	  p[0]=DH11_ReadByte();  
		p[1]=DH11_ReadByte();  
		p[2]=DH11_ReadByte();     
		p[3]=DH11_ReadByte();     
		p[4]=DH11_ReadByte();   
	if(p[0]+p[1]+p[2]+p[3]!=p[4])
	{
	return 1; 
	}
	return 0;
}

void DHT11_Init(void){
	GPIO_DTH11();
	//DHT11_ReadData();
}

