#include "stm32f10x.h"                  // Device header


/**
  * @brief  配置串口1引脚
  * @param  无
  * @retval 无
  */
void UART_Init(void){
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1|RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitTypeDef GPIOUARTT_Init;
	GPIOUARTT_Init.GPIO_Mode=GPIO_Mode_AF_PP;             //设置复用推挽输出模式
	GPIOUARTT_Init.GPIO_Pin=GPIO_Pin_9;
	GPIOUARTT_Init.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIOUARTT_Init);
	
	GPIO_InitTypeDef GPIOUARTR_Init;
	GPIOUARTR_Init.GPIO_Mode=GPIO_Mode_IN_FLOATING;				//设置浮空输入模式
	GPIOUARTR_Init.GPIO_Pin=GPIO_Pin_10;
	GPIOUARTR_Init.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIOUARTR_Init);
	
	
	USART_InitTypeDef USART1_Init;
	USART1_Init.USART_BaudRate=9600;                      //设置波特率为9600
	USART1_Init.USART_HardwareFlowControl=USART_HardwareFlowControl_None;     //设置硬件流控制(这里设置不使用)
	USART1_Init.USART_Mode=USART_Mode_Rx|USART_Mode_Tx;   //设置发送和接受的使能 
	USART1_Init.USART_Parity=USART_Parity_No;             //设置奇偶校验(这里设置无奇偶校验)
	USART1_Init.USART_StopBits=USART_StopBits_1;          //设置停止位(这里设置停止位为1位)
	USART1_Init.USART_WordLength=USART_WordLength_8b;     //设置传输数据长度(这里设置数据长度为8位)
	USART_Init(USART1,&USART1_Init);
	
	USART_Cmd(USART1,ENABLE);                             //使能USART1
	USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);          //打开USART1的接收中断
}

/**
  * @brief  配置USART1中断优先级
  * @param  无
  * @retval 无
  */
void NVIC_USART1(void){
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);        //设置中断优先级分组(这里设置为2)
	
	NVIC_InitTypeDef USART1_NVIC;                          
	USART1_NVIC.NVIC_IRQChannel=USART1_IRQn;               //中断入口参数
	USART1_NVIC.NVIC_IRQChannelCmd=ENABLE;
	USART1_NVIC.NVIC_IRQChannelPreemptionPriority=2;       //抢占优先级
	USART1_NVIC.NVIC_IRQChannelSubPriority=2;              //响应优先级
	NVIC_Init(&USART1_NVIC);
	
}

/**
  * @brief  发送一个字节
  * @param  data @要发送的数据
  * @retval 无
  */
void USART1_First(uint8_t data){
		USART_SendData(USART1,data);                         //USART1发送数据Data
		while(USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET);   //判断数据是否发出
}

/**
  * @brief  发送两个字节
  * @param  data @要发送的数据
  * @retval 无
  */
void USART1_Second(uint16_t data){
 	 uint8_t data_h=(data>>8)&0xff;
	 uint8_t data_l=data&0xff;	
	 USART_SendData(USART1,data_h);                         //USART1发送数据Data
	 while(USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET);   //判断数据是否发出
	 USART_SendData(USART1,data_l);                         //USART1发送数据Data
	 while(USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET);   //判断数据是否发出	
}

/**
  * @brief  发送八位数据
  * @param  data @要发送的数据
  * @param  num  @要发送的数据的长度
  * @retval 无
  */
void USART1_Array(uint8_t *data,uint8_t num){
	uint8_t i;
	for(i=0;i<num;i++){
		USART1_First(data[i]);
	}
	while(USART_GetFlagStatus(USART1,USART_FLAG_TC)==RESET);   //判断一连串数据是否发出	

}

/**
  * @brief  发送字符串
  * @param  data @要发送的数据
  * @param  num  @要发送的数据的长度
  * @retval 无
  */
void USART1_Str(char *Str){          
	uint8_t i=0;
	do{
	USART1_First(*(Str+i));
	i++;
	}while(*(Str+i) != '\0');
	while(USART_GetFlagStatus(USART1,USART_FLAG_TC)==RESET);   //判断一连串数据是否发出	

}

/**
  * @brief  串口1接收中断执行函数
  * @param  无
  * @retval 无
  */
void USART1_IRQHandler(void){
	uint8_t Data;
	if(USART_GetITStatus(USART1,USART_IT_RXNE)){           //判断是否是USART1的接收中断
		Data=USART_ReceiveData(USART1);                      //读取USART1的数据并赋予Data
		USART_SendData(USART1,Data);                         //USART1发送数据Data
	}
	
}
