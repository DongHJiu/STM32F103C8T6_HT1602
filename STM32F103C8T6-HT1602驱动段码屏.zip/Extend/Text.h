#ifndef __TEXT_H
#define __TEXT_H

#include "GUI.h"
#include "Delay.h"



void Text_empty(void);

void Txet_LED_1(uint16_t i);
void Txet_LED_2(uint16_t i);
void Txet_LED_3(uint16_t i, int p);
void Txet_LED_4(uint16_t i, int p);
void Txet_LED_5(uint16_t i, int p);
void Txet_LED_6(uint16_t i, int p);
void Txet_LED_7(uint16_t i, int p);
void Txet_LED_8(uint16_t i);


void Text_LCD_T(float maximum_value, float least_value, float Data);

void Text_LCD_Z(void);

#endif
