#include "stm32f10x.h"                  // Device header
#include "GUI.h"
#include "Delay.h"


#define HT1620_CS(x)   GPIO_WriteBit(GPIOA, GPIO_Pin_1, (BitAction)(x))
#define HT1620_WR(x)   GPIO_WriteBit(GPIOA, GPIO_Pin_2, (BitAction)(x))
#define HT1620_DATA(x) GPIO_WriteBit(GPIOA, GPIO_Pin_3, (BitAction)(x))


/**
  * @brief  TH1620���ų�ʼ��
  * @param  ��
  * @retval ��
  */
void HT1620_GPIO_Init(void){
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitTypeDef HT1620_GPIO;
	HT1620_GPIO.GPIO_Mode = GPIO_Mode_Out_PP;
	HT1620_GPIO.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3;
	HT1620_GPIO.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&HT1620_GPIO);
	
}

/**
  * @brief  TH1620��ʼ
  * @param  ��
  * @retval ��
  */
void HT1620_Start(void){
	HT1620_CS(0);
	HT1620_WR(0);
	HT1620_DATA(0);
}

/**
  * @brief  TH1620ֹͣ
  * @param  ��
  * @retval ��  
  */
void HT1620_Stop(void){
	HT1620_CS(1);
	HT1620_WR(1);
	HT1620_DATA(1);
}


/* --------------------------------------------------------------------------------------------------------------------------------------------- */
/**
  * @brief  ��ʼ��LCD����HT1620оƬ
  * @param  ��
  * @retval ��
  */
void HT1620_Init(void)
{
    HT1620_GPIO_Init();     //gpio��ʼ��
    
    Delay_ms(10);   //��ʱ
    
		HT1620_CS(1);
		HT1620_DATA(1);
		HT1620_WR(1);
    
    Delay_ms(100);                    // ��ʱʹLCD������ѹ�ȶ�
    
    HT1620_WriteCommand(HT1621_SYS_EN); // ��ϵͳ����
    HT1620_WriteCommand(HT1621_BIAS);   // BIAS 13 4��������
    HT1620_WriteCommand(HT1621_RC256);  // ʹ��RC_256Kϵͳʱ��Դ��Ƭ��RC����
    HT1620_WriteCommand(HT1621_WDT_DIS);
    HT1620_WriteCommand(HT1621_LCD_ON);
}

/**
  * @brief  д����������־100
  * @param  com @��������
  * @retval ��
  */
void HT1620_WriteCommand(uint8_t cmd)
{
    uint8_t i;
    
    HT1620_CS(0);                         // CS = 0 
		Delay_ms(1);
    
    // д�������־,DATA:100
    HT1620_WR(0);                         // WR = 0
    Delay_ms(1);
    HT1620_DATA(1);                       // DATA = 1
    Delay_ms(1);
    HT1620_WR(1);                         // WR = 1
    Delay_ms(1);
    
    HT1620_WR(0);                        // WR = 0
    Delay_ms(1);
    HT1620_DATA(0);                       // DATA = 0
    Delay_ms(1);
    HT1620_WR(1);                         // WR = 1
    Delay_ms(1);
    
    HT1620_WR(0);                         // WR = 0
    Delay_ms(1);
    HT1620_DATA(0);                       // DATA = 0
    Delay_ms(1);
    HT1620_WR(1);                         // WR = 1
    Delay_ms(1);
    
    // Datasheet��������C8Ϊ0
    HT1620_WR(0);                         // WR = 0
    Delay_ms(1);
    HT1620_DATA(0);                       // DATA = 0
    Delay_ms(1);
    HT1620_WR(1);                         // WR = 1
    Delay_ms(1);
    
    // Datasheet��������C7~C0
    for(i = 0; i < 8; i++)
    {
        HT1620_WR(0);                     // WR = 0
        Delay_ms(1);
        if((cmd << i) & 0x80)
        {
            HT1620_DATA(1);               // DATA = 1
        }
        else
        {
            HT1620_DATA(0);               // DATA = 0
        }
        Delay_ms(1);
        HT1620_WR(1);                     // WR = 1
        Delay_ms(1);
    }
    
    HT1620_CS(1);                         // CS = 1
    Delay_ms(1);
}

/**
  * @brief  д��4λ���ݣ�д�����ݱ�־101
  * @param  addr @д����ʼ��ַ
  * @param  data @д�����ݣ���ΪHT1620������λ4λ������ʵ��д������Ϊ�����ĺ�4λ
  * @retval ��
  */
void HT1620_WriteData4Bit(uint8_t addr, uint8_t data)
{
    uint8_t i;
    
    HT1620_CS(0);                         // CS = 0 
    Delay_ms(1);
    
    // д�����ݱ�־,DATA:101
    HT1620_WR(0);                         // WR = 0
    Delay_ms(1);
    HT1620_DATA(1);                       // DATA = 1
    Delay_ms(1);
    HT1620_WR(1);                         // WR = 1
    Delay_ms(1);
    
    HT1620_WR(0);                         // WR = 0
    Delay_ms(1);
    HT1620_DATA(0);                       // DATA = 0
    Delay_ms(1);
    HT1620_WR(1);                         // WR = 1
    Delay_ms(1);
    
    HT1620_WR(0);                         // WR = 0
    Delay_ms(1);
    HT1620_DATA(1);                       // DATA = 1
    Delay_ms(1);
    HT1620_WR(1);                         // WR = 1
    Delay_ms(1);
    
    // д���ַ,Datasheet��A5~A0
    for(i = 0; i < 6; i++)
    {
        HT1620_WR(0);                     // WR = 0
        Delay_ms(1);
        if((addr << i) & 0x80)
        {
            HT1620_DATA(1);               // DATA = 1
        }
        else
        {
            HT1620_DATA(0);               // DATA = 0
        }
        Delay_ms(1);
        HT1620_WR(1);                     // WR = 1
        Delay_ms(1);
    }
    // д������,Datasheet�� D0~D3
    for(i = 0; i < 4; i++)
    {
        HT1620_WR(0);                     // WR = 0
        Delay_ms(1);
        if((data >> (3 - i)) & 0x01)
        {
            HT1620_DATA(1);               // DATA = 1
        }
        else
        {
            HT1620_DATA(0);               // DATA = 0
        }
        Delay_ms(1);
        HT1620_WR(1);                     // WR = 1
        Delay_ms(1);
    }
    
    HT1620_CS(1);                         // CS = 1
    Delay_ms(1);    
}

/**
  * @brief  д��8λ���ݣ�д�����ݱ�־101
  * @param  addr @д����ʼ��ַ
  * @param  data @д������
  * @retval ��
  */
void HT1620_WriteData8Bit(uint8_t addr, uint8_t data)
{
    uint8_t i;
    
    HT1620_CS(0);                         // CS = 0 
    Delay_ms(1);
    
    // д�����ݱ�־,DATA:101
    HT1620_WR(0);                         // WR = 0
    Delay_ms(1);
    HT1620_DATA(1);                       // DATA = 1
    Delay_ms(1);
    HT1620_WR(1);                         // WR = 1
    Delay_ms(1);
    
    HT1620_WR(0);                         // WR = 0
    Delay_ms(1);
    HT1620_DATA(0);                       // DATA = 0
    Delay_ms(1);
    HT1620_WR(1);                         // WR = 1
    Delay_ms(1);
    
    HT1620_WR(0);                         // WR = 0
    Delay_ms(1);
    HT1620_DATA(1);                       // DATA = 1
    Delay_ms(1);
    HT1620_WR(1);                         // WR = 1
    Delay_ms(1);
    
    // д���ַ,Datasheet��A5~A0
    for(i = 0; i < 6; i++)
    {
        HT1620_WR(0);                     // WR = 0
        Delay_ms(1);
        if((addr << i) & 0x80)
        {
            HT1620_DATA(1);               // DATA = 1
        }
        else
        {
            HT1620_DATA(0);               // DATA = 0
        }
        Delay_ms(1);
        HT1620_WR(1);                     // WR = 1
        Delay_ms(1);
    }
    // д������,Datasheet������D0~D3
    for(i = 0; i < 8; i++)
    {
        HT1620_WR(0);                     // WR = 0
        Delay_ms(1);
        if((data >> (7 - i)) & 0x01)
        {
            HT1620_DATA(1);               // DATA = 1
        }
        else
        {
            HT1620_DATA(0);               // DATA = 0
        }
        Delay_ms(1);
        HT1620_WR(1);                     // WR = 1
        Delay_ms(1);
    }
    
    HT1620_CS(1);                         // CS = 1
    Delay_ms(1);       
}


/* --------------------------------------------------------------------------------------------------------------------------------------------------- */

/**
  * @brief  д���λ����
  * @param  Byte @д�������
  * @retval ��  
  */
void HT1620_SennByte(uint8_t Byte){
	uint8_t i;
	for(i = 0; i < 8; i++){
		HT1620_WR(0);
		HT1620_DATA(Byte & (0x80 >> i));
		HT1620_WR(1);
	}
}


void HT1620_WriteData(uint8_t Data){
	HT1620_Start();
	 
}


