#include "stm32f10x.h"                  // Device header
#include "Text.h"

/**
  * @brief  ���4~8���������ʾ
  * @param  ��
  * @retval ��
  */
void Text_empty(void){
	
	HT1620_WriteData4Bit(0x7C,0x00);  //1�������
	HT1620_WriteData4Bit(0x78,0x00);	
	HT1620_WriteData4Bit(0x74,0x00);  //2�������
	HT1620_WriteData4Bit(0x70,0x00);	
	HT1620_WriteData4Bit(0x6C,0x00);  //3�������
	HT1620_WriteData4Bit(0x68,0x00); 
	HT1620_WriteData4Bit(0x38,0x00);  //4�������
	HT1620_WriteData4Bit(0x34,0x00);	
	HT1620_WriteData4Bit(0x40,0x00);  //5�������
	HT1620_WriteData4Bit(0x3C,0x00); 
	HT1620_WriteData4Bit(0x48,0x00);  //6�������
	HT1620_WriteData4Bit(0x44,0x00);
	HT1620_WriteData4Bit(0x50,0x00);  //7�������
	HT1620_WriteData4Bit(0x4C,0x00);		
	HT1620_WriteData4Bit(0x58,0x00);  //8�������
	HT1620_WriteData4Bit(0x54,0x00);		
	
	HT1620_WriteData4Bit(0x2C,0x00);  //LCD_Tϵ��
	HT1620_WriteData4Bit(0x28,0x00);
	HT1620_WriteData4Bit(0x24,0x00);
	HT1620_WriteData4Bit(0x20,0x00);
	HT1620_WriteData4Bit(0x1C,0x00);
	HT1620_WriteData4Bit(0x18,0x00); 	
	
	HT1620_WriteData4Bit(0x14,0x00); 		
}


/**
  * @brief  ѡ��1�������Ҫӳ���ֵ
  * @param  i @Ҫӳ���ֵ
  * @retval ��
  */
void Txet_LED_1(uint16_t i){
	switch(i){	
		case 0:{HT1620_WriteData4Bit(0x7C,0x05);
	          HT1620_WriteData4Bit(0x78,0x0F); break;}
		case 1:{HT1620_WriteData4Bit(0x7C,0x00);
	          HT1620_WriteData4Bit(0x78,0x06); break;}			
		case 2:{HT1620_WriteData4Bit(0x7C,0x03);
	          HT1620_WriteData4Bit(0x78,0x0D); break;}			
		case 3:{HT1620_WriteData4Bit(0x7C,0x02);
	          HT1620_WriteData4Bit(0x78,0x0F); break;}			
		case 4:{HT1620_WriteData4Bit(0x7C,0x06);
	          HT1620_WriteData4Bit(0x78,0x06); break;}			
		case 5:{HT1620_WriteData4Bit(0x7C,0x06);
	          HT1620_WriteData4Bit(0x78,0x0B); break;}			
		case 6:{HT1620_WriteData4Bit(0x7C,0x07);
	          HT1620_WriteData4Bit(0x78,0x0B); break;}			
		case 7:{HT1620_WriteData4Bit(0x7C,0x00);
	          HT1620_WriteData4Bit(0x78,0x0E); break;}			
		case 8:{HT1620_WriteData4Bit(0x7C,0x07);
	          HT1620_WriteData4Bit(0x78,0x0F); break;}			
		case 9:{HT1620_WriteData4Bit(0x7C,0x06);
	          HT1620_WriteData4Bit(0x78,0x0F); break;}			
	}
}

/**
  * @brief  ѡ��2�������Ҫӳ���ֵ
  * @param  i @Ҫӳ���ֵ
  * @retval ��
  */
void Txet_LED_2(uint16_t i){
	switch(i){	
		case 0:{HT1620_WriteData4Bit(0x74,0x05);
	          HT1620_WriteData4Bit(0x70,0x0F); break;}
		case 1:{HT1620_WriteData4Bit(0x74,0x00);
	          HT1620_WriteData4Bit(0x70,0x06); break;}			
		case 2:{HT1620_WriteData4Bit(0x74,0x03);
	          HT1620_WriteData4Bit(0x70,0x0D); break;}			
		case 3:{HT1620_WriteData4Bit(0x74,0x02);
	          HT1620_WriteData4Bit(0x70,0x0F); break;}			
		case 4:{HT1620_WriteData4Bit(0x74,0x06);
	          HT1620_WriteData4Bit(0x70,0x06); break;}			
		case 5:{HT1620_WriteData4Bit(0x74,0x06);
	          HT1620_WriteData4Bit(0x70,0x0B); break;}			
		case 6:{HT1620_WriteData4Bit(0x74,0x07);
	          HT1620_WriteData4Bit(0x70,0x0B); break;}			
		case 7:{HT1620_WriteData4Bit(0x74,0x00);
	          HT1620_WriteData4Bit(0x70,0x0E); break;}			
		case 8:{HT1620_WriteData4Bit(0x74,0x07);
	          HT1620_WriteData4Bit(0x70,0x0F); break;}			
		case 9:{HT1620_WriteData4Bit(0x74,0x06);
	          HT1620_WriteData4Bit(0x70,0x0F); break;}			
	}
}

/**
  * @brief  ѡ��3�������Ҫӳ���ֵ
  * @param  i @Ҫӳ���ֵ
  * @param  p @�Ƿ���ʾС����(0:����ʾ��1:��ʾ)
  * @retval ��
  */
void Txet_LED_3(uint16_t i, int p){
	if(p == 0){   //����ʾС����
		switch(i){	
			case 0:{HT1620_WriteData4Bit(0x6C,0x05);
							HT1620_WriteData4Bit(0x68,0x0F); break;}
			case 1:{HT1620_WriteData4Bit(0x6C,0x00);
							HT1620_WriteData4Bit(0x68,0x06); break;}			
			case 2:{HT1620_WriteData4Bit(0x6C,0x03);
							HT1620_WriteData4Bit(0x68,0x0D); break;}			
			case 3:{HT1620_WriteData4Bit(0x6C,0x02);
							HT1620_WriteData4Bit(0x68,0x0F); break;}			
			case 4:{HT1620_WriteData4Bit(0x6C,0x06);
							HT1620_WriteData4Bit(0x68,0x06); break;}			
			case 5:{HT1620_WriteData4Bit(0x6C,0x06);
							HT1620_WriteData4Bit(0x68,0x0B); break;}			
			case 6:{HT1620_WriteData4Bit(0x6C,0x07);
							HT1620_WriteData4Bit(0x68,0x0B); break;}			
			case 7:{HT1620_WriteData4Bit(0x6C,0x00);
							HT1620_WriteData4Bit(0x68,0x0E); break;}			
			case 8:{HT1620_WriteData4Bit(0x6C,0x07);
							HT1620_WriteData4Bit(0x68,0x0F); break;}			
			case 9:{HT1620_WriteData4Bit(0x6C,0x06);
							HT1620_WriteData4Bit(0x68,0x0F); break;}			
		}
}
	else{         //��ʾС����
		switch(i){	
			case 0:{HT1620_WriteData4Bit(0x6C,0x0D);
							HT1620_WriteData4Bit(0x68,0x0F); break;}
			case 1:{HT1620_WriteData4Bit(0x6C,0x08);
							HT1620_WriteData4Bit(0x68,0x06); break;}			
			case 2:{HT1620_WriteData4Bit(0x6C,0x0B);
							HT1620_WriteData4Bit(0x68,0x0D); break;}			
			case 3:{HT1620_WriteData4Bit(0x6C,0x0A);
							HT1620_WriteData4Bit(0x68,0x0F); break;}			
			case 4:{HT1620_WriteData4Bit(0x6C,0x0E);
							HT1620_WriteData4Bit(0x68,0x06); break;}			
			case 5:{HT1620_WriteData4Bit(0x6C,0x0E);
							HT1620_WriteData4Bit(0x68,0x0B); break;}			
			case 6:{HT1620_WriteData4Bit(0x6C,0x0F);
							HT1620_WriteData4Bit(0x68,0x0B); break;}			
			case 7:{HT1620_WriteData4Bit(0x6C,0x08);
							HT1620_WriteData4Bit(0x68,0x0E); break;}			
			case 8:{HT1620_WriteData4Bit(0x6C,0x0F);
							HT1620_WriteData4Bit(0x68,0x0F); break;}			
			case 9:{HT1620_WriteData4Bit(0x6C,0x0E);
							HT1620_WriteData4Bit(0x68,0x0F); break;}			
		}
	}		
}



/**
  * @brief  ѡ��4�������Ҫӳ���ֵ
  * @param  i @Ҫӳ���ֵ
	* @param  p @�Ƿ���ʾС����(0:����ʾ��1:��ʾ)
  * @retval ��
  */
void Txet_LED_4(uint16_t i, int p){
	if(p == 0){        //����ʾС����
		switch(i){
			case 0:{HT1620_WriteData4Bit(0x58,0x0F);
							HT1620_WriteData4Bit(0x54,0x05); break;}
			case 1:{HT1620_WriteData4Bit(0x58,0x06);
							HT1620_WriteData4Bit(0x54,0x00); break;}				
			case 2:{HT1620_WriteData4Bit(0x58,0x0B);
							HT1620_WriteData4Bit(0x54,0x06); break;}						
			case 3:{HT1620_WriteData4Bit(0x58,0x0F);
							HT1620_WriteData4Bit(0x54,0x02); break;}				
			case 4:{HT1620_WriteData4Bit(0x58,0x06);
							HT1620_WriteData4Bit(0x54,0x03); break;}		
			case 5:{HT1620_WriteData4Bit(0x58,0x0D);
							HT1620_WriteData4Bit(0x54,0x03); break;}			
			case 6:{HT1620_WriteData4Bit(0x58,0x0D);
							HT1620_WriteData4Bit(0x54,0x07); break;}		
			case 7:{HT1620_WriteData4Bit(0x58,0x07);
							HT1620_WriteData4Bit(0x54,0x00); break;}			
			case 8:{HT1620_WriteData4Bit(0x58,0x0F);
							HT1620_WriteData4Bit(0x54,0x07); break;}			
			case 9:{HT1620_WriteData4Bit(0x58,0x0F);
							HT1620_WriteData4Bit(0x54,0x03); break;}		
		}
	}
	else{              //��ʾС����
		switch(i){
			case 0:{HT1620_WriteData4Bit(0x58,0x0F);
							HT1620_WriteData4Bit(0x54,0x0D); break;}
			case 1:{HT1620_WriteData4Bit(0x58,0x06);
							HT1620_WriteData4Bit(0x54,0x08); break;}				
			case 2:{HT1620_WriteData4Bit(0x58,0x0B);
							HT1620_WriteData4Bit(0x54,0x0E); break;}						
			case 3:{HT1620_WriteData4Bit(0x58,0x0F);
							HT1620_WriteData4Bit(0x54,0x0A); break;}				
			case 4:{HT1620_WriteData4Bit(0x58,0x06);
							HT1620_WriteData4Bit(0x54,0x0B); break;}		
			case 5:{HT1620_WriteData4Bit(0x58,0x0D);
							HT1620_WriteData4Bit(0x54,0x0B); break;}			
			case 6:{HT1620_WriteData4Bit(0x58,0x0D);
							HT1620_WriteData4Bit(0x54,0x0F); break;}		
			case 7:{HT1620_WriteData4Bit(0x58,0x07);
							HT1620_WriteData4Bit(0x54,0x08); break;}			
			case 8:{HT1620_WriteData4Bit(0x58,0x0F);
							HT1620_WriteData4Bit(0x54,0x0F); break;}			
			case 9:{HT1620_WriteData4Bit(0x58,0x0F);
							HT1620_WriteData4Bit(0x54,0x0B); break;}		
		}		
	}
}

/**
  * @brief  ѡ��5�������Ҫӳ���ֵ
  * @param  i @Ҫӳ���ֵ
	* @param  p @�Ƿ���ʾС����(0:����ʾ��1:��ʾ)
  * @retval ��
  */
void Txet_LED_5(uint16_t i, int p){
	if(p == 0){
		switch(i){		
			case 0:{HT1620_WriteData4Bit(0x50,0x0F);
							HT1620_WriteData4Bit(0x4C,0x05); break;}
			case 1:{HT1620_WriteData4Bit(0x50,0x06);
							HT1620_WriteData4Bit(0x4C,0x00); break;}			
			case 2:{HT1620_WriteData4Bit(0x50,0x0B);
							HT1620_WriteData4Bit(0x4C,0x06); break;}			
			case 3:{HT1620_WriteData4Bit(0x50,0x0F);
							HT1620_WriteData4Bit(0x4C,0x02); break;}			
			case 4:{HT1620_WriteData4Bit(0x50,0x06);
							HT1620_WriteData4Bit(0x4C,0x03); break;}			
			case 5:{HT1620_WriteData4Bit(0x50,0x0D);
							HT1620_WriteData4Bit(0x4C,0x03); break;}			
			case 6:{HT1620_WriteData4Bit(0x50,0x0D);
							HT1620_WriteData4Bit(0x4C,0x07); break;}			
			case 7:{HT1620_WriteData4Bit(0x50,0x07);
							HT1620_WriteData4Bit(0x4C,0x00); break;}			
			case 8:{HT1620_WriteData4Bit(0x50,0x0F);
							HT1620_WriteData4Bit(0x4C,0x07); break;}			
			case 9:{HT1620_WriteData4Bit(0x50,0x0F);
							HT1620_WriteData4Bit(0x4C,0x03); break;}			
		}
	}
	else{
		switch(i){
			case 0:{HT1620_WriteData4Bit(0x50,0x0F);
							HT1620_WriteData4Bit(0x4C,0x0D); break;}
			case 1:{HT1620_WriteData4Bit(0x50,0x06);
							HT1620_WriteData4Bit(0x4C,0x08); break;}				
			case 2:{HT1620_WriteData4Bit(0x50,0x0B);
							HT1620_WriteData4Bit(0x4C,0x0E); break;}						
			case 3:{HT1620_WriteData4Bit(0x50,0x0F);
							HT1620_WriteData4Bit(0x4C,0x0A); break;}				
			case 4:{HT1620_WriteData4Bit(0x50,0x06);
							HT1620_WriteData4Bit(0x4C,0x0B); break;}		
			case 5:{HT1620_WriteData4Bit(0x50,0x0D);
							HT1620_WriteData4Bit(0x4C,0x0B); break;}			
			case 6:{HT1620_WriteData4Bit(0x50,0x0D);
							HT1620_WriteData4Bit(0x4C,0x0F); break;}		
			case 7:{HT1620_WriteData4Bit(0x50,0x07);
							HT1620_WriteData4Bit(0x4C,0x08); break;}			
			case 8:{HT1620_WriteData4Bit(0x50,0x0F);
							HT1620_WriteData4Bit(0x4C,0x0F); break;}			
			case 9:{HT1620_WriteData4Bit(0x50,0x0F);
							HT1620_WriteData4Bit(0x4C,0x0B); break;}		
		}	
	}		
}

/**
  * @brief  ѡ��6�������Ҫӳ���ֵ
  * @param  i @Ҫӳ���ֵ
	* @param  p @�Ƿ���ʾС����(0:����ʾ��1:��ʾ)
  * @retval ��
  */
void Txet_LED_6(uint16_t i, int p){
	if(p == 0){
		switch(i){	
			case 0:{HT1620_WriteData4Bit(0x48,0x0F);
							HT1620_WriteData4Bit(0x44,0x05); break;}
			case 1:{HT1620_WriteData4Bit(0x48,0x06);
							HT1620_WriteData4Bit(0x44,0x00); break;}			
			case 2:{HT1620_WriteData4Bit(0x48,0x0B);
							HT1620_WriteData4Bit(0x44,0x06); break;}			
			case 3:{HT1620_WriteData4Bit(0x48,0x0F);
							HT1620_WriteData4Bit(0x44,0x02); break;}			
			case 4:{HT1620_WriteData4Bit(0x48,0x06);
							HT1620_WriteData4Bit(0x44,0x03); break;}			
			case 5:{HT1620_WriteData4Bit(0x48,0x0D);
							HT1620_WriteData4Bit(0x44,0x03); break;}			
			case 6:{HT1620_WriteData4Bit(0x48,0x0D);
							HT1620_WriteData4Bit(0x44,0x07); break;}			
			case 7:{HT1620_WriteData4Bit(0x48,0x07);
							HT1620_WriteData4Bit(0x44,0x00); break;}			
			case 8:{HT1620_WriteData4Bit(0x48,0x0F);
							HT1620_WriteData4Bit(0x44,0x07); break;}			
			case 9:{HT1620_WriteData4Bit(0x48,0x0F);
							HT1620_WriteData4Bit(0x44,0x03); break;}			
		}
	}
	else{
		switch(i){
			case 0:{HT1620_WriteData4Bit(0x48,0x0F);
							HT1620_WriteData4Bit(0x44,0x0D); break;}
			case 1:{HT1620_WriteData4Bit(0x48,0x06);
							HT1620_WriteData4Bit(0x44,0x08); break;}				
			case 2:{HT1620_WriteData4Bit(0x48,0x0B);
							HT1620_WriteData4Bit(0x44,0x0E); break;}						
			case 3:{HT1620_WriteData4Bit(0x48,0x0F);
							HT1620_WriteData4Bit(0x44,0x0A); break;}				
			case 4:{HT1620_WriteData4Bit(0x48,0x06);
							HT1620_WriteData4Bit(0x44,0x0B); break;}		
			case 5:{HT1620_WriteData4Bit(0x48,0x0D);
							HT1620_WriteData4Bit(0x44,0x0B); break;}			
			case 6:{HT1620_WriteData4Bit(0x48,0x0D);
							HT1620_WriteData4Bit(0x44,0x0F); break;}		
			case 7:{HT1620_WriteData4Bit(0x48,0x07);
							HT1620_WriteData4Bit(0x44,0x08); break;}			
			case 8:{HT1620_WriteData4Bit(0x48,0x0F);
							HT1620_WriteData4Bit(0x44,0x0F); break;}			
			case 9:{HT1620_WriteData4Bit(0x48,0x0F);
							HT1620_WriteData4Bit(0x44,0x0B); break;}		
		}
	}		
}

/**
  * @brief  ѡ��7�������Ҫӳ���ֵ
  * @param  i @Ҫӳ���ֵ
	* @param  p @�Ƿ���ʾС����(0:����ʾ��1:��ʾ)
  * @retval ��
  */
void Txet_LED_7(uint16_t i, int p){
	if(p == 0){
		switch(i){	
			case 0:{HT1620_WriteData4Bit(0x40,0x0F);
							HT1620_WriteData4Bit(0x3C,0x05); break;}
			case 1:{HT1620_WriteData4Bit(0x40,0x06);
							HT1620_WriteData4Bit(0x3C,0x00); break;}			
			case 2:{HT1620_WriteData4Bit(0x40,0x0B);
							HT1620_WriteData4Bit(0x3C,0x06); break;}			
			case 3:{HT1620_WriteData4Bit(0x40,0x0F);
							HT1620_WriteData4Bit(0x3C,0x02); break;}			
			case 4:{HT1620_WriteData4Bit(0x40,0x06);
							HT1620_WriteData4Bit(0x3C,0x03); break;}			
			case 5:{HT1620_WriteData4Bit(0x40,0x0D);
							HT1620_WriteData4Bit(0x3C,0x03); break;}			
			case 6:{HT1620_WriteData4Bit(0x40,0x0D);
							HT1620_WriteData4Bit(0x3C,0x07); break;}			
			case 7:{HT1620_WriteData4Bit(0x40,0x07);
							HT1620_WriteData4Bit(0x3C,0x00); break;}			
			case 8:{HT1620_WriteData4Bit(0x40,0x0F);
							HT1620_WriteData4Bit(0x3C,0x07); break;}			
			case 9:{HT1620_WriteData4Bit(0x40,0x0F);
							HT1620_WriteData4Bit(0x3C,0x03); break;}			
		}
	}
	else{
		switch(i){
			case 0:{HT1620_WriteData4Bit(0x40,0x0F);
							HT1620_WriteData4Bit(0x3C,0x0D); break;}
			case 1:{HT1620_WriteData4Bit(0x40,0x06);
							HT1620_WriteData4Bit(0x3C,0x08); break;}				
			case 2:{HT1620_WriteData4Bit(0x40,0x0B);
							HT1620_WriteData4Bit(0x3C,0x0E); break;}						
			case 3:{HT1620_WriteData4Bit(0x40,0x0F);
							HT1620_WriteData4Bit(0x3C,0x0A); break;}				
			case 4:{HT1620_WriteData4Bit(0x40,0x06);
							HT1620_WriteData4Bit(0x3C,0x0B); break;}		
			case 5:{HT1620_WriteData4Bit(0x40,0x0D);
							HT1620_WriteData4Bit(0x3C,0x0B); break;}			
			case 6:{HT1620_WriteData4Bit(0x40,0x0D);
							HT1620_WriteData4Bit(0x3C,0x0F); break;}		
			case 7:{HT1620_WriteData4Bit(0x40,0x07);
							HT1620_WriteData4Bit(0x3C,0x08); break;}			
			case 8:{HT1620_WriteData4Bit(0x40,0x0F);
							HT1620_WriteData4Bit(0x3C,0x0F); break;}			
			case 9:{HT1620_WriteData4Bit(0x40,0x0F);
							HT1620_WriteData4Bit(0x3C,0x0B); break;}		
		}		
	}
}

/**
  * @brief  ѡ��8�������Ҫӳ���ֵ
  * @param  i @Ҫӳ���ֵ
  * @retval ��
  */
void Txet_LED_8(uint16_t i){
	switch(i){	
		case 0:{HT1620_WriteData4Bit(0x38,0x0F);
	          HT1620_WriteData4Bit(0x34,0x05); break;}
		case 1:{HT1620_WriteData4Bit(0x38,0x06);
	          HT1620_WriteData4Bit(0x34,0x00); break;}			
		case 2:{HT1620_WriteData4Bit(0x38,0x0B);
	          HT1620_WriteData4Bit(0x34,0x06); break;}			
		case 3:{HT1620_WriteData4Bit(0x38,0x0F);
	          HT1620_WriteData4Bit(0x34,0x02); break;}			
		case 4:{HT1620_WriteData4Bit(0x38,0x06);
	          HT1620_WriteData4Bit(0x34,0x03); break;}			
		case 5:{HT1620_WriteData4Bit(0x38,0x0D);
	          HT1620_WriteData4Bit(0x34,0x03); break;}			
		case 6:{HT1620_WriteData4Bit(0x38,0x0D);
	          HT1620_WriteData4Bit(0x34,0x07); break;}			
		case 7:{HT1620_WriteData4Bit(0x38,0x07);
	          HT1620_WriteData4Bit(0x34,0x00); break;}			
		case 8:{HT1620_WriteData4Bit(0x38,0x0F);
	          HT1620_WriteData4Bit(0x34,0x07); break;}			
		case 9:{HT1620_WriteData4Bit(0x38,0x0F);
	          HT1620_WriteData4Bit(0x34,0x03); break;}			
	}
	
}


void Text_LCD_T(float maximum_value, float least_value, float Data){
	float total_value;
	float Data_value;
	uint16_t Data_value_por;
	
	total_value = maximum_value - least_value;
	Data = Data - least_value;
	Data_value = Data / total_value;
	Data_value_por = Data_value * 100;

	while(1){
		if(Data_value_por == 0){
			HT1620_WriteData4Bit(0x2C,0x00);
			HT1620_WriteData4Bit(0x28,0x00);
			HT1620_WriteData4Bit(0x24,0x00);
			HT1620_WriteData4Bit(0x20,0x00);
			HT1620_WriteData4Bit(0x1C,0x00);
	    HT1620_WriteData4Bit(0x18,0x01); 
			break;
		}
		else if(Data_value_por < 5){
			HT1620_WriteData4Bit(0x2C,0x00);
			HT1620_WriteData4Bit(0x28,0x00);
			HT1620_WriteData4Bit(0x24,0x00);
			HT1620_WriteData4Bit(0x20,0x00);
			HT1620_WriteData4Bit(0x1C,0x00);
	    HT1620_WriteData4Bit(0x18,0x05); 
			break;
		}
		else if(Data_value_por < 10){
			HT1620_WriteData4Bit(0x2C,0x00);
			HT1620_WriteData4Bit(0x28,0x00);
			HT1620_WriteData4Bit(0x24,0x00);
			HT1620_WriteData4Bit(0x20,0x00);
			HT1620_WriteData4Bit(0x1C,0x00);
	    HT1620_WriteData4Bit(0x18,0x0D); 			
			break;
		}
		else if(Data_value_por < 15){
			HT1620_WriteData4Bit(0x2C,0x00);
			HT1620_WriteData4Bit(0x28,0x00);
			HT1620_WriteData4Bit(0x24,0x00);
			HT1620_WriteData4Bit(0x20,0x00);
			HT1620_WriteData4Bit(0x1C,0x08);
	    HT1620_WriteData4Bit(0x18,0x0D); 			
			break;
		}
		else if(Data_value_por < 20){
			HT1620_WriteData4Bit(0x2C,0x00);
			HT1620_WriteData4Bit(0x28,0x00);
			HT1620_WriteData4Bit(0x24,0x00);
			HT1620_WriteData4Bit(0x20,0x00);
			HT1620_WriteData4Bit(0x1C,0x0C);
	    HT1620_WriteData4Bit(0x18,0x0D);			
			break;
		}
		else if(Data_value_por < 25){
			HT1620_WriteData4Bit(0x2C,0x00);
			HT1620_WriteData4Bit(0x28,0x00);
			HT1620_WriteData4Bit(0x24,0x00);
			HT1620_WriteData4Bit(0x20,0x00);
			HT1620_WriteData4Bit(0x1C,0x0E);
	    HT1620_WriteData4Bit(0x18,0x0D);			
			break;
		}
		else if(Data_value_por < 30){
			HT1620_WriteData4Bit(0x2C,0x00);
			HT1620_WriteData4Bit(0x28,0x00);
			HT1620_WriteData4Bit(0x24,0x00);
			HT1620_WriteData4Bit(0x20,0x00);
			HT1620_WriteData4Bit(0x1C,0x0F);
	    HT1620_WriteData4Bit(0x18,0x0D);			
			break;
		}
		else if(Data_value_por < 35){
			HT1620_WriteData4Bit(0x2C,0x00);
			HT1620_WriteData4Bit(0x28,0x00);
			HT1620_WriteData4Bit(0x24,0x00);
			HT1620_WriteData4Bit(0x20,0x01);
			HT1620_WriteData4Bit(0x1C,0x0F);
	    HT1620_WriteData4Bit(0x18,0x0D);				
			break;
		}
		else if(Data_value_por < 40){
			HT1620_WriteData4Bit(0x2C,0x00);
			HT1620_WriteData4Bit(0x28,0x00);
			HT1620_WriteData4Bit(0x24,0x00);
			HT1620_WriteData4Bit(0x20,0x03);
			HT1620_WriteData4Bit(0x1C,0x0F);
	    HT1620_WriteData4Bit(0x18,0x0D);				
			break;
		}
		else if(Data_value_por < 45){
			HT1620_WriteData4Bit(0x2C,0x00);
			HT1620_WriteData4Bit(0x28,0x00);
			HT1620_WriteData4Bit(0x24,0x00);
			HT1620_WriteData4Bit(0x20,0x07);
			HT1620_WriteData4Bit(0x1C,0x0F);
	    HT1620_WriteData4Bit(0x18,0x0D);				
			break;
		}
		else if(Data_value_por < 50){
			HT1620_WriteData4Bit(0x2C,0x00);
			HT1620_WriteData4Bit(0x28,0x00);
			HT1620_WriteData4Bit(0x24,0x00);
			HT1620_WriteData4Bit(0x20,0x0F);
			HT1620_WriteData4Bit(0x1C,0x0F);
	    HT1620_WriteData4Bit(0x18,0x0D);				
			break;
		}
		else if(Data_value_por < 55){
			HT1620_WriteData4Bit(0x2C,0x00);
			HT1620_WriteData4Bit(0x28,0x00);
			HT1620_WriteData4Bit(0x24,0x08);
			HT1620_WriteData4Bit(0x20,0x0F);
			HT1620_WriteData4Bit(0x1C,0x0F);
	    HT1620_WriteData4Bit(0x18,0x0D);				
			break;
		}
		else if(Data_value_por < 60){
			HT1620_WriteData4Bit(0x2C,0x00);
			HT1620_WriteData4Bit(0x28,0x00);
			HT1620_WriteData4Bit(0x24,0x0C);
			HT1620_WriteData4Bit(0x20,0x0F);
			HT1620_WriteData4Bit(0x1C,0x0F);
	    HT1620_WriteData4Bit(0x18,0x0D);			
			break;
		}
		else if(Data_value_por < 65){
			HT1620_WriteData4Bit(0x2C,0x00);
			HT1620_WriteData4Bit(0x28,0x00);
			HT1620_WriteData4Bit(0x24,0x0E);
			HT1620_WriteData4Bit(0x20,0x0F);
			HT1620_WriteData4Bit(0x1C,0x0F);
	    HT1620_WriteData4Bit(0x18,0x0D);			
			break;
		}
		else if(Data_value_por < 70){
			HT1620_WriteData4Bit(0x2C,0x00);
			HT1620_WriteData4Bit(0x28,0x00);
			HT1620_WriteData4Bit(0x24,0x0F);
			HT1620_WriteData4Bit(0x20,0x0F);
			HT1620_WriteData4Bit(0x1C,0x0F);
	    HT1620_WriteData4Bit(0x18,0x0C);			
			break;
		}
		else if(Data_value_por < 75){
			HT1620_WriteData4Bit(0x2C,0x00);
			HT1620_WriteData4Bit(0x28,0x01);
			HT1620_WriteData4Bit(0x24,0x0F);
			HT1620_WriteData4Bit(0x20,0x0F);
			HT1620_WriteData4Bit(0x1C,0x0F);
	    HT1620_WriteData4Bit(0x18,0x0D);			
			break;
		}
		else if(Data_value_por < 80){
			HT1620_WriteData4Bit(0x2C,0x00);
			HT1620_WriteData4Bit(0x28,0x03);
			HT1620_WriteData4Bit(0x24,0x0F);
			HT1620_WriteData4Bit(0x20,0x0F);
			HT1620_WriteData4Bit(0x1C,0x0F);
	    HT1620_WriteData4Bit(0x18,0x0D);			
			break;
		}
		else if(Data_value_por < 85){
			HT1620_WriteData4Bit(0x2C,0x00);
			HT1620_WriteData4Bit(0x28,0x07);
			HT1620_WriteData4Bit(0x24,0x0F);
			HT1620_WriteData4Bit(0x20,0x0F);
			HT1620_WriteData4Bit(0x1C,0x0F);
	    HT1620_WriteData4Bit(0x18,0x0D);			
			break;
		}
		else if(Data_value_por < 90){
			HT1620_WriteData4Bit(0x2C,0x00);
			HT1620_WriteData4Bit(0x28,0x0F);
			HT1620_WriteData4Bit(0x24,0x0F);
			HT1620_WriteData4Bit(0x20,0x0F);
			HT1620_WriteData4Bit(0x1C,0x0F);
	    HT1620_WriteData4Bit(0x18,0x0D);			
			break;
		}
		else if(Data_value_por < 95){
			HT1620_WriteData4Bit(0x2C,0x08);
			HT1620_WriteData4Bit(0x28,0x0F);
			HT1620_WriteData4Bit(0x24,0x0F);
			HT1620_WriteData4Bit(0x20,0x0F);
			HT1620_WriteData4Bit(0x1C,0x0F);
	    HT1620_WriteData4Bit(0x18,0x0D);				
			break;
		}		
		else if(Data_value_por < 100){
			HT1620_WriteData4Bit(0x2C,0x0C);
			HT1620_WriteData4Bit(0x28,0x0F);
			HT1620_WriteData4Bit(0x24,0x0F);
			HT1620_WriteData4Bit(0x20,0x0F);
			HT1620_WriteData4Bit(0x1C,0x0F);
	    HT1620_WriteData4Bit(0x18,0x0D);				
			break;
		}		
	}		
}



void Text_LCD_Z(void){
	HT1620_WriteData4Bit(0x64,0x01);
}

